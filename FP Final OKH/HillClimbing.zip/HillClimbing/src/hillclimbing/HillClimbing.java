package hillclimbing;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class HillClimbing {

    static String Direktori = "D:/Kuliah/Semester 6/OKH A/Toronto/";
        static String namafile[][] = {
            {"car-f-92", "Carleton92"}, 
            {"car-s-91", "Carleton91"},
            {"ear-f-83", "EarlHaig83"}, 
            {"hec-s-92", "EdHec92"}, 
            {"kfu-s-93", "KingFahd93"}, 
            {"lse-f-91", "LSE91"},
            {"pur-s-93", "Pur93"}, 
            {"rye-s-93", "Rye93"},
            {"sta-f-83", "St.Andrews83"}, 
            {"tre-s-92", "Trent92"}, 
            {"uta-s-92", "TorontoAS92"}, 
            {"ute-s-92", "TorontoE92"},
            {"yor-f-83", "YorkMills83"}
        };
    static String file, Input, Output;
    
    static int totalExams;
    
    static int timeslot[]; // fill with course & its timeslot	
    static int[][] conflictMatrix, courseSorted, timeslotResult;
	
    private static Scanner scanner;
	
    public static void main(String[] args) throws IOException {
        scanner = new Scanner(System.in);
        for	(int i=0; i< namafile.length; i++)
        	System.out.println(i+1 + ". " + namafile[i][1]);
        
        System.out.print("\nPilih dataset yang diinginkan : ");
        int dataset = scanner.nextInt();
        
        Input = namafile[dataset-1][0];
        Output = namafile[dataset-1][1];
        
        file = Direktori + Input;
		
        Course course = new Course(file);
        int totalExams = course.getTotalCourse();
        
        conflictMatrix = course.getConflictMatrix();
        int totalStudents = course.getTotalMurid();
        
		// sort exam by degree
		courseSorted = course.sortingByDegree(conflictMatrix, totalExams);
		
		// Hill Climbing Algorithm
                long starttimeHC = System.nanoTime();
		new Optimizer(file).getTimeslotByHillClimbing(conflictMatrix, courseSorted, totalExams, totalStudents, 1000000); // use hillclimbing methode for iterates 1000000 times
		long endtime = System.nanoTime();
		// end time
		double runningtime = (double) (endtime - starttimeHC)/1000000000;
                
                // Initial solution by Largest Degree
 
		
		System.out.println("Time : " + runningtime + " detik.");
                
    }
}