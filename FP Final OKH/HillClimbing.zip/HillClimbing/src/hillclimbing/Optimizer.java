package hillclimbing;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class Optimizer {
	int[][] timeslotHillClimbing, conflictMatrix, courseSorted;
	int[] timeslot;
	String file;
	int jumlahexam, randomCourse, randomTimeslot;
	
	Optimizer(String file) { this.file = file; }
	
	// hill climbing method
	public void getTimeslotByHillClimbing(int[][] conflictMatrix, int[][] courseSorted, int totalExams, int totalStudents, int iterasi) throws IOException {
	
		Schedule schedule = new Schedule(file, conflictMatrix, totalExams);
		timeslot = schedule.schedulingByDegree(courseSorted);
		
		timeslotHillClimbing = schedule.getSchedule(); // initial feasible solution
		int[][] timeslotHillClimbingSementara = new int[timeslotHillClimbing.length][2]; // handle temporary solution. if better than feasible, replace initial
		
		// copy timeslotHillClimbing to timeslotHillClimbingSementara
		for (int i = 0; i < timeslotHillClimbingSementara.length; i ++) {
			timeslotHillClimbingSementara[i][0] = timeslotHillClimbing[i][0]; // fill with course
			timeslotHillClimbingSementara[i][1] = timeslotHillClimbing[i][1]; // fill with timeslot
		}
		
		double fitnessLD = Solution.getPenalty(conflictMatrix, timeslotHillClimbing, totalStudents);
		
		for(int i = 0; i < iterasi; i++) {
			try {
				randomCourse = randomNumber(0, totalExams); // random course
				randomTimeslot = randomNumber(0, schedule.getHowManyTimeSlot(timeslot)); // random timeslot
				timeslotHillClimbingSementara[randomCourse][1] = randomTimeslot;
			
				if (Schedule.checkRandomTimeslot(randomCourse, randomTimeslot, conflictMatrix, timeslotHillClimbing)) {	
					timeslotHillClimbingSementara[randomCourse][1] = randomTimeslot;
					double fitnessHC = Solution.getPenalty(conflictMatrix, timeslotHillClimbingSementara, totalStudents);
					
					// compare between penalti. replace initial with after if initial penalti is greater
					if(fitnessLD > fitnessHC) {
						fitnessLD = fitnessHC;
						timeslotHillClimbing[randomCourse][1] = timeslotHillClimbingSementara[randomCourse][1];
					} 
						else 
							timeslotHillClimbingSementara[randomCourse][1] = timeslotHillClimbing[randomCourse][1];
				}
				//System.out.println("jadwaltemp ke " + randomCourseIndex);
				//System.out.println("Random timeslot ke " + randomTimeslot);
				System.out.println("Iterasi ke " + (i+1) + " memiliki fitness : "+fitnessLD);
			}
				catch (ArrayIndexOutOfBoundsException e) {
					//System.out.println("randomCourseIndex index ke- " + randomCourseIndex);
					//System.out.println("randomTimeslot index ke- " + randomTimeslot);
				}
			
		}
		

            System.out.println("Fitness akhir : " + fitnessLD); 
	}
	
	public static int randomNumber(int min, int max) {
		Random random = new Random();
		return random.nextInt(max - min) + min;
	}
}
