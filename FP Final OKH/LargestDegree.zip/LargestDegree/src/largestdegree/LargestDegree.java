/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largestdegree;


import java.io.IOException;
import java.util.Scanner;

public class LargestDegree {
	
	static final String Direktori = "D:/Kuliah/Semester 6/OKH A/Toronto/";
        static String namafile[][] = {
            {"car-f-92", "Carleton92"}, 
            {"car-s-91", "Carleton91"},
            {"ear-f-83", "EarlHaig83"}, 
            {"hec-s-92", "EdHec92"}, 
            {"kfu-s-93", "KingFahd93"}, 
            {"lse-f-91", "LSE91"},
            {"pur-s-93", "Pur93"}, 
            {"rye-s-93", "Rye93"},
            {"sta-f-83", "St.Andrews83"}, 
            {"tre-s-92", "Trent92"}, 
            {"uta-s-92", "TorontoAS92"}, 
            {"ute-s-92", "TorontoE92"},
            {"yor-f-83", "YorkMills83"}
        };
        static int timeslot[]; 
        static int[][] conflictMatrix, courseSorted, timeslotResult;
	
	public static void main(String[] args) throws IOException {
		
		for(int i=0; i< namafile.length; i++)
        	System.out.println(i+1 + ". " + namafile[i][1]);
                
		System.out.print("\nPilih dataset yang diinginkan : ");
		Scanner input = new Scanner(System.in);
		int dataset = input.nextInt();
                
                String filePilihanInput = namafile[dataset-1][0];
                String filePilihanOutput = namafile[dataset-1][1];
  
            String file = Direktori + filePilihanInput;
        	
            Course course = new Course(file);
            int totalExams = course.getTotalCourse();
        
            conflictMatrix = course.getConflictMatrix();
            int totalStudents = course.getTotalMurid();
        
            conflictMatrix = new int[totalExams][totalExams];  
            conflictMatrix = course.getConflictMatrix();
        
            for (int i=0; i<10; i++) {
		for(int j=0; j<10; j++) {	
                    }
            }
		
            // sort exam by degree
            courseSorted = course.sortingByDegree(conflictMatrix, totalExams);
     
            //Scheduling by largest degree
            long starttimeLD = System.nanoTime();
            Schedule schedule = new Schedule(file, conflictMatrix, totalExams);
            timeslot = schedule.schedulingByDegree(courseSorted);
            int[][] timeslotLD = schedule.getSchedule();
            long endtimeLD = System.nanoTime();
            System.out.println("Timeslots  	: " + schedule.getTotalTimeslots(schedule.getSchedule()));
            System.out.println("Fitness 	: " + Solution.getPenalty(conflictMatrix, schedule.getSchedule(), totalStudents));
            System.out.println("Time            : " + ((double) (endtimeLD - starttimeLD)/1000000000) + " detik.\n");
	}
}
